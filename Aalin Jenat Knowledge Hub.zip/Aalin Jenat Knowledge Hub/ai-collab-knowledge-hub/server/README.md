# AI-Powered Collaborative Knowledge Hub — Server

Express + MongoDB + JWT + Google Gemini

## Quick Start
```bash
cd server
cp .env.example .env
# fill in MONGO_URI, JWT_SECRET, GEMINI_API_KEY
npm install
npm run dev
```
Server runs on `http://localhost:5000` by default.

## API Overview
- `POST /api/auth/register`
- `POST /api/auth/login` → returns JWT
- `GET /api/docs` → list docs (auth)
- `POST /api/docs` → create doc (auto summary, tags, embeddings)
- `GET /api/docs/:id` / `PUT /api/docs/:id` / `DELETE /api/docs/:id`
- `GET /api/search` → `?q=...&semantic=true|false`
- `POST /api/ai/qa` → body: `{ question: string }` returns answer with citations

Role rules: `admin` can edit/delete any doc; `user` only their own.
