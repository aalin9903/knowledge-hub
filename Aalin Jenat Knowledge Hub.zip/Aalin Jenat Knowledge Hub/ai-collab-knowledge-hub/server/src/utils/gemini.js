import { GoogleGenerativeAI, GoogleAIEmbeddings } from "@google/generative-ai";

const apiKey = process.env.GEMINI_API_KEY;
const genModelName = process.env.GENERATIVE_MODEL || "gemini-1.5-pro";
const embedModelName = process.env.EMBEDDING_MODEL || "text-embedding-004";

const genAI = apiKey ? new GoogleGenerativeAI(apiKey) : null;

export async function summarizeAndTag(title, content) {
  if (!genAI) return { summary: content.slice(0, 160) + "...", tags: ["note"] };
  const model = genAI.getGenerativeModel({ model: genModelName });
  const prompt = `Summarize the following document in 2-3 sentences and suggest 5 short, lowercase tags (comma separated).
Title: ${title}
Content: ${content}`;
  const resp = await model.generateContent(prompt);
  const text = (await resp.response).text();
  const lines = text.split("\n").map(s => s.trim()).filter(Boolean);
  const summary = lines[0] || "";
  const tagsLine = (lines.slice(1).join(" ") || "").replace(/tags\s*:\s*/i, "");
  const tags = tagsLine.split(",").map(t => t.trim()).filter(Boolean).slice(0,5);
  return { summary, tags: tags.length ? tags : ["general"] };
}

export async function embed(text) {
  if (!apiKey) return [];
  const embedder = new GoogleAIEmbeddings({ apiKey, model: embedModelName });
  const result = await embedder.embedContent(text);
  return result.embedding.values;
}

export async function answerWithContext(question, docs) {
  if (!genAI) {
    return { answer: "AI is not configured. Provide GEMINI_API_KEY.", cites: docs.map(d => d._id) };
  }
  const model = genAI.getGenerativeModel({ model: genModelName });
  const context = docs.map(d => `- ${d.title}: ${d.summary}\n${(d.content || '').substring(0, 4000)}`).join("\n\n");
  const prompt = `You are an assistant answering questions using ONLY the provided team documents.
If something is not in the documents, say you don't know. Provide concise answers and cite doc titles used.

QUESTION: ${question}

DOCUMENTS:
${context}`;
  const resp = await model.generateContent(prompt);
  const text = (await resp.response).text();
  return { answer: text, cites: docs.map(d => d.title) };
}
