import express from "express";
import { requireAuth } from "../middleware/auth.js";
import Document from "../models/Document.js";
import { answerWithContext } from "../utils/gemini.js";

const router = express.Router();

router.post("/qa", requireAuth, async (req, res) => {
  const { question } = req.body;
  if (!question) return res.status(400).json({ error: "question required" });
  // pick top docs by recency for context (simple heuristic)
  const docs = await Document.find().sort({ updatedAt: -1 }).limit(6);
  const result = await answerWithContext(question, docs);
  res.json(result);
});

export default router;
