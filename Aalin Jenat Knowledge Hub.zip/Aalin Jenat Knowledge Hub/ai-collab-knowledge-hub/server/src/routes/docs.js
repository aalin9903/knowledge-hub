import express from "express";
import Document from "../models/Document.js";
import Activity from "../models/Activity.js";
import { requireAuth } from "../middleware/auth.js";
import { summarizeAndTag, embed } from "../utils/gemini.js";

const router = express.Router();

const canEdit = (user, doc) => user.role === "admin" || String(doc.createdBy) === String(user._id);

// List with recent team activity (last 5 edits) appended
router.get("/", requireAuth, async (req, res) => {
  const docs = await Document.find().populate("createdBy", "name email role").sort({ updatedAt: -1 }).limit(50);
  const activity = await Activity.find().sort({ createdAt: -1 }).limit(5).populate("userId", "name").populate("docId", "title");
  res.json({ docs, activity });
});

router.post("/", requireAuth, async (req, res) => {
  try {
    const { title, content } = req.body;
    const { summary, tags } = await summarizeAndTag(title, content);
    const embedding = await embed(`${title}\n${content}`);
    const doc = await Document.create({
      title, content, tags, summary, createdBy: req.user._id, embedding,
      versions: [{ content, editedBy: req.user._id }]
    });
    await Activity.create({ action: "create", docId: doc._id, userId: req.user._id });
    res.json(doc);
  } catch (e) {
    res.status(500).json({ error: "Create failed" });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  const doc = await Document.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  res.json(doc);
});

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const doc = await Document.findById(req.params.id);
    if (!doc) return res.status(404).json({ error: "Not found" });
    if (!canEdit(req.user, doc)) return res.status(403).json({ error: "Forbidden" });
    const { title, content } = req.body;
    if (title !== undefined) doc.title = title;
    if (content !== undefined) {
      doc.content = content;
      doc.versions.push({ content, editedBy: req.user._id });
      // re-summarize and re-embed on edit
      const { summary, tags } = await summarizeAndTag(doc.title, doc.content);
      doc.summary = summary;
      doc.tags = tags;
      doc.embedding = await embed(`${doc.title}\n${doc.content}`);
    }
    doc.updatedBy = req.user._id;
    await doc.save();
    await Activity.create({ action: "update", docId: doc._id, userId: req.user._id });
    res.json(doc);
  } catch (e) {
    res.status(500).json({ error: "Update failed" });
  }
});

router.delete("/:id", requireAuth, async (req, res) => {
  const doc = await Document.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  if (!canEdit(req.user, doc)) return res.status(403).json({ error: "Forbidden" });
  await doc.deleteOne();
  await Activity.create({ action: "delete", docId: doc._id, userId: req.user._id });
  res.json({ ok: true });
});

// Basic & semantic search (cosine similarity in-app)
router.get("/search/text", requireAuth, async (req, res) => {
  const q = req.query.q || "";
  const regex = new RegExp(q, "i");
  const docs = await Document.find({ $or: [{ title: regex }, { content: regex }, { tags: regex }] }).limit(50);
  res.json(docs);
});

router.get("/search", requireAuth, async (req, res) => {
  const q = req.query.q || "";
  const semantic = String(req.query.semantic) === "true";
  if (!semantic) {
    const regex = new RegExp(q, "i");
    const docs = await Document.find({ $or: [{ title: regex }, { content: regex }, { tags: regex }] }).limit(50);
    return res.json(docs);
  }
  // semantic
  try {
    const qEmbed = await embed(q);
    const all = await Document.find({}, "title summary tags embedding");
    const cosine = (a, b) => {
      if (!a?.length || !b?.length) return 0;
      let dot = 0, na = 0, nb = 0;
      const n = Math.min(a.length, b.length);
      for (let i=0;i<n;i++){ dot += a[i]*b[i]; na += a[i]*a[i]; nb += b[i]*b[i]; }
      return dot / (Math.sqrt(na) * Math.sqrt(nb) + 1e-9);
    };
    const ranked = all.map(d => ({ doc: d, score: cosine(qEmbed, d.embedding || []) }))
                      .sort((x,y) => y.score - x.score)
                      .slice(0, 20);
    res.json(ranked);
  } catch (e) {
    res.status(500).json({ error: "Semantic search failed. Check GEMINI_API_KEY." });
  }
});

export default router;
