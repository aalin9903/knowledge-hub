import mongoose from "mongoose";

const versionSchema = new mongoose.Schema({
  content: String,
  editedAt: { type: Date, default: Date.now },
  editedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { _id: false });

const docSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  tags: [{ type: String }],
  summary: { type: String, default: "" },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  embedding: [{ type: Number }],
  versions: [versionSchema],
}, { timestamps: true });

export default mongoose.model("Document", docSchema);
