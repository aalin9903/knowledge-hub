import React from "react";

export default function DocCard({ doc, onOpen }) {
  return (
    <div className="card cursor-pointer" onClick={() => onOpen(doc)}>
      <div className="flex items-start justify-between">
        <h3 className="font-semibold">{doc.title}</h3>
        <div className="text-xs text-gray-500">{new Date(doc.updatedAt).toLocaleString()}</div>
      </div>
      <p className="text-sm mt-2 line-clamp-2">{doc.summary || doc.content?.slice(0,140)}</p>
      <div className="mt-2 flex flex-wrap">
        {(doc.tags||[]).map((t, idx) => <span key={idx} className="tag">{t}</span>)}
      </div>
      <div className="text-xs text-gray-600 mt-2">Author: {doc.createdBy?.name || "unknown"}</div>
    </div>
  );
}
