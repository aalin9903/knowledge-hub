import React from "react";

export default function ActivityFeed({ activity }) {
  return (
    <div className="card">
      <h2 className="font-semibold mb-2">Team Activity</h2>
      <ul className="space-y-2 text-sm">
        {activity.map((a) => (
          <li key={a._id}>
            <b>{a.userId?.name || "Someone"}</b> {a.action} <i>{a.docId?.title || "a doc"}</i> — {new Date(a.createdAt).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
