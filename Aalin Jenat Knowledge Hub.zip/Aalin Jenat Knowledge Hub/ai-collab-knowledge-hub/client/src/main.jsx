import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./styles.css";
import App from "./App.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import EditDoc from "./pages/EditDoc.jsx";
import Search from "./pages/Search.jsx";
import QA from "./pages/QA.jsx";

const AuthRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  return token ? children : <Navigate to="/login" replace />;
};

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Routes>
      <Route element={<App />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<AuthRoute><Dashboard /></AuthRoute>} />
        <Route path="/docs/new" element={<AuthRoute><EditDoc /></AuthRoute>} />
        <Route path="/docs/:id" element={<AuthRoute><EditDoc /></AuthRoute>} />
        <Route path="/search" element={<AuthRoute><Search /></AuthRoute>} />
        <Route path="/qa" element={<AuthRoute><QA /></AuthRoute>} />
      </Route>
    </Routes>
  </BrowserRouter>
);
