import React from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";

export default function App() {
  const nav = useNavigate();
  const logout = () => { localStorage.removeItem("token"); nav("/login"); };
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="flex items-center justify-between p-4 border-b bg-white">
        <div className="font-semibold">AI Knowledge Hub</div>
        <nav className="flex gap-3">
          <Link className="btn" to="/">Dashboard</Link>
          <Link className="btn" to="/search">Search</Link>
          <Link className="btn" to="/qa">Team Q&A</Link>
          <button className="btn" onClick={logout}>Logout</button>
        </nav>
      </header>
      <main className="p-4 max-w-5xl mx-auto">
        <Outlet />
      </main>
    </div>
  );
}
