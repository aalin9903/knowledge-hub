import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api";

export default function EditDoc() {
  const { id } = useParams();
  const nav = useNavigate();
  const isNew = id === undefined;
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [versions, setVersions] = useState([]);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data } = await api.get(`/api/docs/${id}`);
      setTitle(data.title); setContent(data.content); setVersions(data.versions || []);
    })();
  }, [id]);

  const save = async () => {
    if (isNew) {
      const { data } = await api.post("/api/docs", { title, content });
      nav(`/docs/${data._id}`);
    } else {
      await api.put(`/api/docs/${id}`, { title, content });
      alert("Saved!");
      window.location.reload();
    }
  };

  const remove = async () => {
    if (!confirm("Delete this doc?")) return;
    await api.delete(`/api/docs/${id}`);
    nav("/");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 card">
        <h1 className="font-semibold mb-3">{isNew ? "New" : "Edit"} Document</h1>
        <input className="input mb-3" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <textarea className="input h-64" placeholder="Content" value={content} onChange={e=>setContent(e.target.value)} />
        <div className="flex gap-2 mt-3">
          <button className="btn bg-black text-white" onClick={save}>Save</button>
          {!isNew && <button className="btn" onClick={remove}>Delete</button>}
        </div>
      </div>
      {!isNew && (
        <div className="card">
          <h2 className="font-semibold mb-2">Version History</h2>
          <ul className="space-y-2 text-sm max-h-80 overflow-auto">
            {versions?.slice().reverse().map((v, idx) => (
              <li key={idx}>
                <div className="text-xs text-gray-500">{new Date(v.editedAt).toLocaleString()}</div>
                <pre className="whitespace-pre-wrap">{(v.content||"").slice(0,180)}{(v.content||"").length>180?"...":""}</pre>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
