import React, { useState } from "react";
import api from "../api";

export default function QA() {
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState("");

  const ask = async () => {
    const { data } = await api.post("/api/ai/qa", { question: q });
    setAnswer(data.answer || JSON.stringify(data));
  };

  return (
    <div className="card">
      <h1 className="font-semibold mb-3">Team Q&A</h1>
      <div className="flex gap-2">
        <input className="input" placeholder="Ask a question about team docs" value={q} onChange={e=>setQ(e.target.value)} />
        <button className="btn bg-black text-white" onClick={ask}>Ask</button>
      </div>
      {answer && (
        <div className="mt-4 whitespace-pre-wrap text-sm">{answer}</div>
      )}
    </div>
  );
}
