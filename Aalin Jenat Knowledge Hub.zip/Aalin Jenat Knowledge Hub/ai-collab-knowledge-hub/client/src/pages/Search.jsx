import React, { useState } from "react";
import api from "../api";

export default function Search() {
  const [q, setQ] = useState("");
  const [semantic, setSemantic] = useState(true);
  const [results, setResults] = useState([]);

  const go = async () => {
    const { data } = await api.get(`/api/docs/search?q=${encodeURIComponent(q)}&semantic=${semantic}`);
    setResults(data);
  };

  return (
    <div className="card">
      <h1 className="font-semibold mb-3">Search</h1>
      <div className="flex gap-2">
        <input className="input" placeholder="Search query" value={q} onChange={e=>setQ(e.target.value)} />
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={semantic} onChange={e=>setSemantic(e.target.checked)} />
          Semantic
        </label>
        <button className="btn bg-black text-white" onClick={go}>Search</button>
      </div>
      <div className="mt-4 space-y-2">
        {results.map((r, idx) => (
          <div key={idx} className="card">
            {"doc" in r ? (
              <>
                <div className="text-xs text-gray-500">score: {r.score.toFixed(3)}</div>
                <h3 className="font-semibold">{r.doc.title}</h3>
                <p className="text-sm">{r.doc.summary}</p>
                <div className="mt-1 flex flex-wrap">{(r.doc.tags||[]).map((t, i)=><span key={i} className="tag">{t}</span>)}</div>
              </>
            ) : (
              <>
                <h3 className="font-semibold">{r.title}</h3>
                <p className="text-sm">{r.summary}</p>
                <div className="mt-1 flex flex-wrap">{(r.tags||[]).map((t, i)=><span key={i} className="tag">{t}</span>)}</div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
