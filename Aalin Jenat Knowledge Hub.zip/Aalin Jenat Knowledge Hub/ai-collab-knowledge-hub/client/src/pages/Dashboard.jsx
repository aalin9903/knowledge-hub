import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../api";
import DocCard from "../components/DocCard.jsx";
import ActivityFeed from "../components/ActivityFeed.jsx";

export default function Dashboard() {
  const [docs, setDocs] = useState([]);
  const [activity, setActivity] = useState([]);
  const nav = useNavigate();

  useEffect(() => {
    (async () => {
      const { data } = await api.get("/api/docs");
      setDocs(data.docs || []);
      setActivity(data.activity || []);
    })();
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      <div className="lg:col-span-3 space-y-3">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-semibold">Documents</h1>
          <Link to="/docs/new" className="btn bg-black text-white">New Doc</Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {docs.map(d => <DocCard key={d._id} doc={d} onOpen={(doc)=>nav(`/docs/${doc._id}`)} />)}
        </div>
      </div>
      <div className="lg:col-span-1">
        <ActivityFeed activity={activity} />
      </div>
    </div>
  );
}
