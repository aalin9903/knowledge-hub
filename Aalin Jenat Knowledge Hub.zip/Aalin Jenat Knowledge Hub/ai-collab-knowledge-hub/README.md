# AI-Powered Collaborative Knowledge Hub (MERN + Gemini)



## Features (as required)
- Auth (email/password) + JWT
- Roles: `user`, `admin` (admin can edit/delete any doc)
- Documents CRUD: `title`, `content`, `tags`, `summary`, `createdBy`, timestamps
- Gemini AI:
  - Auto **summary** + **tags**
  - **Semantic search** using embeddings
  - **Team Q&A** over stored docs
- Search API: regular text + semantic (cosine similarity in app)
- **Versioning**: each edit stored in `versions[]`
- **Team Activity Feed**: last 5 edits shown on dashboard

## Quick Start
1. **Server**
   ```bash
   cd server
   cp .env.example .env  # fill MONGO_URI, JWT_SECRET, GEMINI_API_KEY
   npm install
   npm run dev
   ```
2. **Client**
   ```bash
   cd ../client
   cp .env.example .env  # adjust VITE_API_URL if needed
   npm install
   npm run dev
   ```


